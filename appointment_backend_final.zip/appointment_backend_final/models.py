from sqlalchemy import Column, Integer, String
from database import Base

class Appointment(Base):
    __tablename__ = "appointments"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    doctor= Column(String, nullable= False)
    time = Column(String, nullable=False)
    email = Column(String, nullable=False)