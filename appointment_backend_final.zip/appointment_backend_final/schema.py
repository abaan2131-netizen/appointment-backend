from pydantic import BaseModel

class AppointmentCreate(BaseModel):
    name: str
    doctor: str
    time: str
    email: str

class Appointment(BaseModel):
    id: int
    name: str
    doctor: str
    time: str
    email: str

    class Config:
        orm_mode = True

