\# Appointment Backend



\## Requirements

\- Python 3.8+ installed

\- From the project folder, run:

&nbsp;   pip install -r requirements.txt



\## How to run

1\. Open terminal/PowerShell in this folder.

2\. Start the server:

&nbsp;   uvicorn main:app --reload

3\. Open API docs in browser:

&nbsp;   http://127.0.0.1:8000/docs



\## Files included

\- main.py        : FastAPI app

\- crud.py        : DB functions

\- models.py      : SQLAlchemy models

\- database.py    : DB connection

\- schema.py      : Pydantic schemas

\- email\_sender.py: (optional) sends confirmation emails

\- appointment.db : SQLite database (optional)

\- requirements.txt

