from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
import database, models, schema, crud
import email_sender

models.Base.metadata.create_all(bind=database.engine)

app = FastAPI()

def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.get("/")
def root():
    return {"message": "Backend is working!"}


# ------------------------ CREATE ------------------------
@app.post("/book")
def book_appointment(appointment: schema.AppointmentCreate, db: Session = Depends(get_db)):
    saved_appointment = crud.create_appointment(db, appointment)

    # Send email after saving
    email_sender.send_email(
        to_email="patient@example.com",
        subject="Appointment Confirmation",
        message=f"Your appointment for {appointment.name} is booked at {appointment.time}."
    )

    return saved_appointment


# ------------------------ READ ------------------------
@app.get("/all")
def get_all(db: Session = Depends(get_db)):
    return crud.get_appointments(db)


# ------------------------ UPDATE ------------------------
@app.put("/update/{appointment_id}")
def update(appointment_id: int, appointment: schema.AppointmentCreate, db: Session = Depends(get_db)):
    return crud.update_appointment(db, appointment_id, appointment)


# ------------------------ DELETE ------------------------
@app.delete("/delete/{appointment_id}")
def delete(appointment_id: int, db: Session = Depends(get_db)):
    return crud.delete_appointment(db, appointment_id)


# ------------------------ SEARCH BY NAME ------------------------
@app.get("/search/name/{name}")
def search_name(name: str, db: Session = Depends(get_db)):
    return crud.search_by_name(db, name)


# ------------------------ SEARCH BY DOCTOR ------------------------
@app.get("/search/doctor/{doctor}")
def search_doctor(doctor: str, db: Session = Depends(get_db)):
    return crud.search_by_doctor(db, doctor)


# ------------------------ FREE SLOTS ------------------------
@app.get("/free-slots/{doctor}")
def free_slots(doctor: str, db: Session = Depends(get_db)):
    return crud.get_free_slots(db, doctor)


# ------------------------ RUN SERVER ------------------------
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)