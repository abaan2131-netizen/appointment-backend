from sqlalchemy.orm import Session
import models, schema

# ============================================
#                CREATE APPOINTMENT
# ============================================
def create_appointment(db: Session, appointment: schema.AppointmentCreate):
    # Check if doctor already has an appointment at same time
    existing = db.query(models.Appointment).filter(
        models.Appointment.doctor == appointment.doctor,
        models.Appointment.time == appointment.time
    ).first()

    if existing:
        return {"error": "This time slot is already booked for this doctor."}

    new_appointment = models.Appointment(
        name=appointment.name,
        doctor=appointment.doctor,
        time=appointment.time,
        email=appointment.email
    )
    db.add(new_appointment)
    db.commit()
    db.refresh(new_appointment)
    return new_appointment


# ============================================
#                READ / GET APPOINTMENTS
# ============================================
def get_appointments(db: Session):
    return db.query(models.Appointment).all()


# ============================================
#                UPDATE APPOINTMENT
# ============================================
def update_appointment(db: Session, appointment_id: int, updated_data: schema.AppointmentCreate):
    appt = db.query(models.Appointment).filter(
        models.Appointment.id == appointment_id
    ).first()

    if not appt:
        return {"error": "Appointment not found"}

    appt.name = updated_data.name
    appt.doctor = updated_data.doctor
    appt.time = updated_data.time

    db.commit()
    db.refresh(appt)
    return appt


# ============================================
#                DELETE APPOINTMENT
# ============================================
def delete_appointment(db: Session, appointment_id: int):
    appointment = db.query(models.Appointment).filter(
        models.Appointment.id == appointment_id
    ).first()

    if appointment is None:
        return {"error": "Appointment not found"}

    db.delete(appointment)
    db.commit()
    return {"message": "Appointment deleted successfully"}


# ============================================
#                SEARCH BY NAME
# ============================================
def search_by_name(db: Session, name: str):
    return db.query(models.Appointment).filter(
        models.Appointment.name == name
    ).all()


# ============================================
#                SEARCH BY DOCTOR
# ============================================
def search_by_doctor(db: Session, doctor: str):
    return db.query(models.Appointment).filter(
        models.Appointment.doctor == doctor
    ).all()


# ============================================
#                FREE SLOTS CHECKER
# ============================================
def get_free_slots(db: Session, doctor: str):
    all_slots = ["9:00", "9:30", "10:00", "10:30", "11:00", "11:30"]

    booked = db.query(models.Appointment).filter(
        models.Appointment.doctor == doctor
    ).all()

    booked_slots = [a.time for a in booked]

    free_slots = [slot for slot in all_slots if slot not in booked_slots]

    return {
        "doctor": doctor,
        "booked_slots": booked_slots,
        "free_slots": free_slots
    }