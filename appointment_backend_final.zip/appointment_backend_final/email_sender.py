def send_email(to_email, subject, message):
    print(f"Email sent to {to_email}")
    print(f"Subject: {subject}")
    print(f"Message: {message}")
    return True